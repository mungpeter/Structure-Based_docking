#!/usr/bin/perl -w

$HOME  = $ARGV[0];	# home directory
$FOLD  = $ARGV[1];	# ligand folder directory (1 level up)
$SRCH  = $ARGV[2];	# home directory of result
$LIB   = $ARGV[3];      # ligand folder name
$TOTAL = $ARGV[4];	# total of ligand found in folder
$STEP  = $ARGV[5];	# how many ligand to run on each CPU
$LSF   = $ARGV[6];	# template pbs for vina run
$CONF  = $ARGV[7];
$CPU   = $ARGV[8];
$LGSUB = $ARGV[9];
$PROT  = $ARGV[10];
$submit = $ARGV[11];

print "  ## $TOTAL ligands found in ".$LIB."/".$LGSUB." ##\n";

$NUM   = 1+int( ($TOTAL/$STEP) + ($TOTAL/$STEP)/abs($TOTAL*2/$STEP) );
$START = 0;
$LAST  = 0;  
print "  ## Number of 'step' LSF will be run: ".$NUM." ##\n";

for ($i = 1; $i <= $NUM; $i++) {

  $out = $PROT.".".$LGSUB.".lsf.".$i;
  open OUT, "> $out";
  open INP, "< $LSF";

  $LAST = $START + $STEP - 1;

  while (<INP>) {

    s/PROT/$PROT/;
    s/FOLD/$FOLD/;
    s/HOME/$HOME/;
    s/SRCH/$SRCH/;
    s/LIB/$LIB/;
    s/START/$START/;
    s/LAST/$LAST/;
    s/CONF/$CONF/;
    s/CPU/$CPU/;
    s/LGSUB/$LGSUB/;
    print OUT;
  }

  $START = $LAST + 1;

  close OUT;
  close INP;
  
  system("bsub < $out") if $submit;
}
